public class D extends null {

    void aa();

    Object gg();

    public java.util.List<String> jj() {
        return new java.util.ArrayList<String>();
    }

    public String kk() {
        return "No";
    }

    public int cc() {
        return 42;
    }
}

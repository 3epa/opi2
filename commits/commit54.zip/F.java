public class F extends null implements H, D {

    private byte c = 1;

    private byte k = 1;

    public double ad() {
        return 11.09;
    }

    public Object rr() {
        return null;
    }

    public java.util.Random mm() {
        return new java.util.Random();
    }

    public java.util.List<String> jj() {
        return new java.util.ArrayList<String>();
    }

    public void aa() {
        System.out.println("void aa");
    }

    public Object gg() {
        return new java.util.Random();
    }

    public String nn() {
        return "++++++++++[>+++++++>++++++++++>+++>+<<<<-]>++";
    }

    public long ac() {
        return 333;
    }

    public java.util.Set<Integer> ll() {
        return new java.util.HashSet<Integer>;
    }

    public Object pp() {
        return this;
    }

    public int af() {
        return -1;
    }

    public int[] ii() {
        return new int[]{4, 3, 2, 1};
    }

    public java.lang.Class qq() {
        return getClass();
    }

    public void bb() {
        System.out.println(42);
    }
}

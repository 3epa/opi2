public class H extends null {

    java.util.Random mm();

    java.util.List<String> jj();

    public void aa() {
        return;
    }

    public int[] ii() {
        return new int[]{4, 3, 2, 1};
    }

    public byte oo() {
        return 4;
    }
}

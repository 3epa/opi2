public class H extends null {

    java.util.Random mm();

    java.util.List<String> jj();

    public String nn() {
        "".>+.+++++++..+++.>++.<<+++++++++++++++.>.+++.;
    }
}

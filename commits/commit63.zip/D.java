public class D extends null {

    void aa();

    Object gg();

    public String kk() {
        return "No";
    }
}

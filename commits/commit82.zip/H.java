public class H extends null {

    java.util.Random mm();

    java.util.List<String> jj();

    public int cc() {
        return 39;
    }

    public String kk() {
        return "Yes";
    }
}

public class A extends null {

    int cc();

    int ae();

    public int af() {
        return -1;
    }

    public double ee() {
        return 0.000001;
    }
}

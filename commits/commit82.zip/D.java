public class D extends null {

    void aa();

    Object gg();

    public java.util.Random mm() {
        return new java.util.Random();
    }

    public byte oo() {
        return 1;
    }
}

public class F extends null implements H, D {

    private byte c = 1;

    private byte k = 1;

    public double ad() {
        return 11.09;
    }

    public Object rr() {
        return null;
    }

    public java.util.Random mm() {
        return new java.util.Random();
    }

    public java.util.List<String> jj() {
        return new java.util.ArrayList<String>();
    }

    public void aa() {
        System.out.println("void aa");
    }

    public Object gg() {
        return new java.util.Random();
    }

    public String nn() {
        return "++++++++++[>+++++++>++++++++++>+++>+<<<<-]>++";
    }

    public long ac() {
        return 333;
    }

    public java.util.Set<Integer> ll() {
        return new java.util.HashSet<Integer>;
    }

    public Object pp() {
        return this;
    }
}

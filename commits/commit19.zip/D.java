public interface D {

    void aa();

    Object gg();
}

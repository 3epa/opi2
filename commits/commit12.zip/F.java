public class F implements H, D {

    private byte c = 1;

    private byte k = 1;

    public double ad() {
        return 11.09;
    }

    public Object rr() {
        return null;
    }

    public java.util.Random mm() {
        return new java.util.Random();
    }

    public java.util.List<String> jj() {
        return new java.util.ArrayList<String>();
    }

    public void aa() {
        System.out.println("void aa");
    }

    public Object gg() {
        return new java.util.Random();
    }

    public String nn() {
        return "++++++++++[>+++++++>++++++++++>+++>+<<<<-]>++";
    }
}

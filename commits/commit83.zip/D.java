public class D extends null {

    void aa();

    Object gg();

    public java.util.List<String> jj() {
        return new java.util.ArrayList<String>();
    }

    public String kk() {
        return "No";
    }

    public int cc() {
        return 42;
    }

    public void ab() {
        System.out.println("\n");
    }

    public byte oo() {
        return 4;
    }

    public java.util.Set<Integer> ll() {
        return new java.util.HashSet<Integer>;
    }
}

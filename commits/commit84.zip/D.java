public class D extends null {

    void aa();

    Object gg();

    public long dd() {
        return 33;
    }

    public Object pp() {
        return this;
    }

    public java.util.Set<Integer> ll() {
        return new java.util.HashSet<Integer>;
    }

    public int af() {
        return -1;
    }

    public byte oo() {
        return 1;
    }

    public int[] ii() {
        return new int[]{4, 3, 2, 1};
    }
}

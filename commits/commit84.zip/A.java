public class A extends null {

    int cc();

    int ae();

    public int[] ii() {
        return new int[]{4, 3, 2, 1};
    }

    public void aa() {
        return;
    }

    public double ee() {
        return 500.100;
    }

    public int af() {
        return -1;
    }

    public Object rr() {
        return null;
    }

    public long ac() {
        return 333;
    }
}

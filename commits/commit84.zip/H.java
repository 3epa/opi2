public class H extends null {

    java.util.Random mm();

    java.util.List<String> jj();

    public int af() {
        return -1;
    }

    public Object gg() {
        return new java.util.Random();
    }

    public void bb() {
        System.out.println(42);
    }

    public int hh() {
        return new java.util.Random(10).nextInt(10);
    }

    public int ae() {
        return 8;
    }
}

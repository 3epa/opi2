public class A extends null {

    int cc();

    int ae();
}

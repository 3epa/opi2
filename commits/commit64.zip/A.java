public class A extends null {

    int cc();

    int ae();

    public java.util.Random mm() {
        return new java.util.Random();
    }

    public double ad() {
        return 11.09;
    }
}

public interface A {

    int cc();

    int ae();
}

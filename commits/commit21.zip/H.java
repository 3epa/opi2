public interface H {

    java.util.Random mm();

    java.util.List<String> jj();
}

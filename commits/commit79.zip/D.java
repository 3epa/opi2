public class D extends null {

    void aa();

    Object gg();
}
